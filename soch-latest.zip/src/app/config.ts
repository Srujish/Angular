export class Config {
 static url = '/api';
}
